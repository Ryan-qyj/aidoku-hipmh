#!/usr/bin/env bash
set -euo pipefail
cargo +nightly build --release
mkdir -p target/wasm32-unknown-unknown/release/Payload
cp res/* target/wasm32-unknown-unknown/release/Payload/
aidoku package target/wasm32-unknown-unknown/release/aidoku_hipmh.wasm
