#![no_std]

use aidoku::{
    alloc::{String, Vec},
    prelude::*,
    Chapter, Manga, MangaPageResult, Page, Result, Source,
};

struct HipMh;

impl Source for HipMh {
    fn new() -> Self {
        Self
    }

    fn get_search_manga_list(
        &self,
        _query: Option<String>,
        _page: i32,
        _filters: Vec<FilterValue>,
    ) -> Result<MangaPageResult> {
        // TODO: integrate HipMH /v1/search and map real results.
        Ok(MangaPageResult {
            entries: Vec::new(),
            has_next_page: false,
        })
    }

    fn get_manga_update(
        &self,
        manga: Manga,
        _needs_details: bool,
        _needs_chapters: bool,
    ) -> Result<Manga> {
        // TODO: fetch manga metadata and paginated chapter list.
        Ok(manga)
    }

    fn get_page_list(&self, _manga: Manga, _chapter: Chapter) -> Result<Vec<Page>> {
        // TODO: parse reader HTML, request /v2/chapter, decode image payload,
        // and resolve URLs using the data-* image base attributes.
        Ok(Vec::new())
    }
}

register_source!(HipMh);
