# HipMH Aidoku source — starter scaffold

This is a starter project, not a completed source. The repository integration currently allows reading metadata but rejects file writes (HTTP 403), so this bundle is provided for manual upload.

## Project layout
- `src/lib.rs`: Aidoku `Source` trait scaffold
- `res/source.json`: source metadata
- `build.sh`: build and package with `aidoku-cli`
- `.github/workflows/build.yml`: CI build

## Build requirements
Install Rust nightly, `wasm32-unknown-unknown`, and `aidoku-cli` from the official Aidoku Rust repository. Run `./build.sh`.

## Important
HipMH's chapter reader uses a dynamically supplied API base URL and image-base attributes from the reader page. Do not hardcode one API host or assume image URLs can be derived from chapter IDs alone. Search, detail, chapter pagination, and image decryption still require integration and live tests before this can be called functional.
